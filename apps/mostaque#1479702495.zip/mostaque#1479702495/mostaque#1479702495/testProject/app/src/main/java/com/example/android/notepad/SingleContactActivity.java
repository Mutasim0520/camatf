package com.example.android.notepad;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;

public class SingleContactActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_contact);
    }
}
